import Link from "next/link";

export default function Home() {
  return (
    <main>
      {/* Nav */}
      <header className="max-w-6xl mx-auto px-6 py-6 flex items-center justify-between">
        <div className="font-display text-xl tracking-tight">Ledger</div>
        <nav className="flex items-center gap-6 text-sm">
          <a href="#pricing" className="text-inkSoft hover:text-ink">Pricing</a>
          <Link href="/login" className="text-inkSoft hover:text-ink">Log in</Link>
          <Link href="/register" className="btn-primary !px-4 !py-2 text-xs">
            Start free
          </Link>
        </nav>
      </header>

      {/* Hero */}
      <section className="max-w-6xl mx-auto px-6 pt-12 pb-24 grid md:grid-cols-2 gap-16 items-center">
        <div>
          <p className="text-xs uppercase tracking-[0.2em] text-brass mb-4">
            Invoicing, No. 001
          </p>
          <h1 className="font-display text-5xl md:text-6xl leading-[1.05] mb-6">
            Send invoices that look like your work does.
          </h1>
          <p className="text-inkSoft text-lg mb-8 max-w-md">
            Ledger is built for independent designers, writers, and studios who
            are tired of invoices that look like a bank generated them.
            Sequential numbering, clean paper, paid in full.
          </p>
          <div className="flex items-center gap-4">
            <Link href="/register" className="btn-primary">
              Start your first invoice
            </Link>
            <a href="#pricing" className="text-sm text-inkSoft hover:text-ink underline underline-offset-4">
              See pricing
            </a>
          </div>
          <p className="text-xs text-inkSoft mt-4">
            14-day free trial. $12/month after. Cancel anytime.
          </p>
        </div>

        {/* Signature element: live invoice mockup */}
        <div className="relative">
          <div className="absolute -top-4 -left-4 w-full h-full border border-hairline" />
          <div className="relative bg-paperLight border border-ink p-8 shadow-[6px_6px_0_0_#1E2A38]">
            <div className="flex justify-between items-start mb-8">
              <div>
                <div className="font-display text-lg">Marlowe & Finch Studio</div>
                <div className="text-xs text-inkSoft mt-1">hello@marlowefinch.co</div>
              </div>
              <div className="text-right">
                <div className="font-mono text-xs text-inkSoft">INVOICE</div>
                <div className="font-mono text-lg">No. 0042</div>
              </div>
            </div>
            <div className="ledger-rule mb-4" />
            <div className="flex justify-between text-xs text-inkSoft mb-6">
              <span>Bill to: Atlas Coffee Co.</span>
              <span>Due: Aug 14, 2026</span>
            </div>
            <table className="w-full text-sm mb-6">
              <tbody>
                <tr className="border-b border-hairline">
                  <td className="py-2 text-inkSoft">Brand identity, phase 2</td>
                  <td className="py-2 text-right font-mono">$3,200.00</td>
                </tr>
                <tr className="border-b border-hairline">
                  <td className="py-2 text-inkSoft">Packaging concepts (x3)</td>
                  <td className="py-2 text-right font-mono">$1,450.00</td>
                </tr>
              </tbody>
            </table>
            <div className="flex justify-between items-baseline">
              <span className="text-xs uppercase tracking-widest text-inkSoft">Total due</span>
              <span className="font-display text-3xl">$4,650.00</span>
            </div>
            <div className="mt-6 inline-flex items-center gap-2 border border-moss text-moss px-3 py-1 text-xs uppercase tracking-widest -rotate-3">
              Paid in full
            </div>
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="bg-ink text-paperLight py-20">
        <div className="max-w-6xl mx-auto px-6 grid md:grid-cols-3 gap-12">
          <Feature
            title="Sequential by design"
            body="Every invoice is numbered in order automatically, the way an accountant actually expects to see it. No more guessing what number you're on."
          />
          <Feature
            title="Clients see paper, not software"
            body="Invoices render as clean, printable documents. Nothing that looks like it came from a dashboard template."
          />
          <Feature
            title="One plan, everything included"
            body="Unlimited clients and invoices. No per-invoice fees, no feature paywalls inside your own subscription."
          />
        </div>
      </section>

      {/* Pricing */}
      <section id="pricing" className="max-w-3xl mx-auto px-6 py-24 text-center">
        <p className="text-xs uppercase tracking-[0.2em] text-brass mb-4">Pricing</p>
        <h2 className="font-display text-4xl mb-4">One studio, one price.</h2>
        <p className="text-inkSoft mb-10">No tiers to compare. Everything, every month.</p>
        <div className="border border-ink bg-paperLight p-10 max-w-sm mx-auto">
          <div className="font-display text-5xl mb-2">$12</div>
          <div className="text-xs uppercase tracking-widest text-inkSoft mb-8">per month</div>
          <ul className="text-sm text-inkSoft space-y-2 mb-8 text-left">
            <li>— Unlimited invoices &amp; clients</li>
            <li>— Sequential invoice numbering</li>
            <li>— Stripe-backed billing portal</li>
            <li>— 14-day free trial</li>
          </ul>
          <Link href="/register" className="btn-primary w-full">
            Start free trial
          </Link>
        </div>
      </section>

      <footer className="border-t border-hairline py-8 text-center text-xs text-inkSoft">
        Ledger — built for people who make things.
      </footer>
    </main>
  );
}

function Feature({ title, body }: { title: string; body: string }) {
  return (
    <div>
      <h3 className="font-display text-xl mb-3">{title}</h3>
      <p className="text-paper/70 text-sm leading-relaxed">{body}</p>
    </div>
  );
}
