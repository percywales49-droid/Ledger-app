import { NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { z } from "zod";

const lineItemSchema = z.object({
  description: z.string().min(1),
  quantity: z.number().positive(),
  unitPrice: z.number().nonnegative(),
});

const createSchema = z.object({
  clientName: z.string().min(1),
  clientEmail: z.string().email().optional().or(z.literal("")),
  dueDate: z.string(),
  taxRate: z.number().min(0).max(100).default(0),
  notes: z.string().optional(),
  lineItems: z.array(lineItemSchema).min(1),
});

async function requireActiveUser() {
  const session = await getServerSession(authOptions);
  if (!session?.user) return null;
  const user = await prisma.user.findUnique({ where: { id: (session.user as any).id } });
  return user;
}

export async function GET() {
  const user = await requireActiveUser();
  if (!user) return NextResponse.json({ error: "Not authenticated." }, { status: 401 });

  const invoices = await prisma.invoice.findMany({
    where: { userId: user.id },
    include: { client: true, lineItems: true },
    orderBy: { number: "desc" },
  });

  return NextResponse.json({ invoices });
}

export async function POST(req: Request) {
  const user = await requireActiveUser();
  if (!user) return NextResponse.json({ error: "Not authenticated." }, { status: 401 });

  if (!["TRIALING", "ACTIVE"].includes(user.planStatus)) {
    return NextResponse.json(
      { error: "Your subscription is inactive. Update billing to keep creating invoices." },
      { status: 402 }
    );
  }

  const body = await req.json();
  const parsed = createSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ error: parsed.error.flatten() }, { status: 400 });
  }
  const data = parsed.data;

  const result = await prisma.$transaction(async (tx) => {
    const client = await tx.client.create({
      data: {
        userId: user.id,
        name: data.clientName,
        email: data.clientEmail || null,
      },
    });

    const updatedUser = await tx.user.update({
      where: { id: user.id },
      data: { invoiceCounter: { increment: 1 } },
    });

    const invoice = await tx.invoice.create({
      data: {
        userId: user.id,
        clientId: client.id,
        number: updatedUser.invoiceCounter,
        dueDate: new Date(data.dueDate),
        taxRate: data.taxRate,
        notes: data.notes,
        lineItems: {
          create: data.lineItems.map((li, idx) => ({
            description: li.description,
            quantity: li.quantity,
            unitPrice: li.unitPrice,
            sortOrder: idx,
          })),
        },
      },
      include: { lineItems: true, client: true },
    });

    return invoice;
  });

  return NextResponse.json({ invoice: result });
}
