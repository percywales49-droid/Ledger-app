import { NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";

async function requireUser() {
  const session = await getServerSession(authOptions);
  if (!session?.user) return null;
  return prisma.user.findUnique({ where: { id: (session.user as any).id } });
}

export async function GET(_req: Request, { params }: { params: { id: string } }) {
  const user = await requireUser();
  if (!user) return NextResponse.json({ error: "Not authenticated." }, { status: 401 });

  const invoice = await prisma.invoice.findFirst({
    where: { id: params.id, userId: user.id },
    include: { lineItems: true, client: true, user: true },
  });
  if (!invoice) return NextResponse.json({ error: "Not found." }, { status: 404 });

  return NextResponse.json({ invoice });
}

export async function PATCH(req: Request, { params }: { params: { id: string } }) {
  const user = await requireUser();
  if (!user) return NextResponse.json({ error: "Not authenticated." }, { status: 401 });

  const body = await req.json();
  const invoice = await prisma.invoice.updateMany({
    where: { id: params.id, userId: user.id },
    data: { status: body.status },
  });
  if (invoice.count === 0) return NextResponse.json({ error: "Not found." }, { status: 404 });

  return NextResponse.json({ ok: true });
}

export async function DELETE(_req: Request, { params }: { params: { id: string } }) {
  const user = await requireUser();
  if (!user) return NextResponse.json({ error: "Not authenticated." }, { status: 401 });

  await prisma.invoice.deleteMany({ where: { id: params.id, userId: user.id } });
  return NextResponse.json({ ok: true });
}
