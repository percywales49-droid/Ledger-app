"use client";

import { signIn } from "next-auth/react";
import { useState } from "react";
import Link from "next/link";

export default function RegisterPage() {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    setError("");

    const res = await fetch("/api/register", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ name, email, password }),
    });

    if (!res.ok) {
      const body = await res.json().catch(() => ({}));
      setError(body.error || "Something went wrong creating your account.");
      setLoading(false);
      return;
    }

    // Log them in immediately, then send to checkout to start the trial.
    const signInRes = await signIn("credentials", { email, password, redirect: false });
    if (signInRes?.error) {
      setError("Account created — please log in.");
      setLoading(false);
      return;
    }

    const checkoutRes = await fetch("/api/stripe/checkout", { method: "POST" });
    const { url } = await checkoutRes.json();
    window.location.href = url;
  }

  return (
    <main className="min-h-screen flex items-center justify-center px-6">
      <div className="w-full max-w-sm">
        <Link href="/" className="font-display text-xl block text-center mb-8">
          Ledger
        </Link>
        <div className="border border-hairline bg-paperLight p-8">
          <h1 className="font-display text-2xl mb-2">Start your trial</h1>
          <p className="text-sm text-inkSoft mb-6">14 days free, then $12/month.</p>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="label">Name</label>
              <input className="field" required value={name} onChange={(e) => setName(e.target.value)} />
            </div>
            <div>
              <label className="label">Email</label>
              <input
                className="field"
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
              />
            </div>
            <div>
              <label className="label">Password</label>
              <input
                className="field"
                type="password"
                required
                minLength={8}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
              />
            </div>
            {error && <p className="text-rust text-sm">{error}</p>}
            <button type="submit" disabled={loading} className="btn-primary w-full">
              {loading ? "Setting up…" : "Continue to checkout"}
            </button>
          </form>
        </div>
        <p className="text-center text-sm text-inkSoft mt-6">
          Already have an account? <Link href="/login" className="text-ink underline underline-offset-4">Log in</Link>
        </p>
      </div>
    </main>
  );
}
