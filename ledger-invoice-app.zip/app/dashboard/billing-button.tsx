"use client";

import { useState } from "react";

export default function BillingButton() {
  const [loading, setLoading] = useState(false);

  async function openPortal() {
    setLoading(true);
    const res = await fetch("/api/stripe/portal", { method: "POST" });
    const { url } = await res.json();
    window.location.href = url;
  }

  return (
    <button onClick={openPortal} disabled={loading} className="text-inkSoft hover:text-ink">
      {loading ? "Opening…" : "Billing"}
    </button>
  );
}
