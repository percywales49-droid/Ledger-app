import { getServerSession } from "next-auth";
import { redirect } from "next/navigation";
import Link from "next/link";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import SignOutButton from "./sign-out-button";
import BillingButton from "./billing-button";

export default async function DashboardLayout({ children }: { children: React.ReactNode }) {
  const session = await getServerSession(authOptions);
  if (!session?.user) redirect("/login");

  const user = await prisma.user.findUnique({ where: { id: (session.user as any).id } });
  if (!user) redirect("/login");

  const isInactive = !["TRIALING", "ACTIVE"].includes(user.planStatus);

  return (
    <div className="min-h-screen">
      <header className="border-b border-hairline">
        <div className="max-w-5xl mx-auto px-6 py-4 flex items-center justify-between">
          <Link href="/dashboard" className="font-display text-lg">Ledger</Link>
          <nav className="flex items-center gap-6 text-sm">
            <Link href="/dashboard/invoices" className="text-inkSoft hover:text-ink">Invoices</Link>
            <Link href="/dashboard/invoices/new" className="text-inkSoft hover:text-ink">New invoice</Link>
            <BillingButton />
            <SignOutButton />
          </nav>
        </div>
      </header>

      {isInactive && (
        <div className="bg-rust text-paperLight text-sm text-center py-2">
          Your subscription isn't active.{" "}
          <Link href="#" className="underline">Update billing</Link> to keep creating invoices.
        </div>
      )}

      <main className="max-w-5xl mx-auto px-6 py-10">{children}</main>
    </div>
  );
}
