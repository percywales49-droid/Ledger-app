import { getServerSession } from "next-auth";
import Link from "next/link";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";

export default async function DashboardHome() {
  const session = await getServerSession(authOptions);
  const user = await prisma.user.findUnique({ where: { id: (session!.user as any).id } });
  const invoices = await prisma.invoice.findMany({
    where: { userId: user!.id },
    include: { lineItems: true },
    orderBy: { number: "desc" },
    take: 5,
  });

  const outstanding = invoices
    .filter((i) => i.status !== "PAID")
    .reduce((sum, inv) => sum + inv.lineItems.reduce((s, li) => s + li.quantity * li.unitPrice, 0), 0);

  return (
    <div>
      <div className="flex items-baseline justify-between mb-8">
        <h1 className="font-display text-3xl">Welcome back{user?.name ? `, ${user.name}` : ""}.</h1>
        <Link href="/dashboard/invoices/new" className="btn-primary">
          New invoice
        </Link>
      </div>

      <div className="grid grid-cols-3 gap-px bg-hairline mb-10 border border-hairline">
        <Stat label="Outstanding" value={`$${outstanding.toLocaleString()}`} />
        <Stat label="Total invoices" value={String(user?.invoiceCounter ?? 0)} />
        <Stat label="Plan status" value={user?.planStatus ?? "NONE"} />
      </div>

      <h2 className="font-display text-xl mb-4">Recent invoices</h2>
      {invoices.length === 0 ? (
        <p className="text-inkSoft text-sm">
          No invoices yet. <Link href="/dashboard/invoices/new" className="underline">Create your first one</Link>.
        </p>
      ) : (
        <div className="border border-hairline">
          {invoices.map((inv) => {
            const total = inv.lineItems.reduce((s, li) => s + li.quantity * li.unitPrice, 0);
            return (
              <Link
                key={inv.id}
                href={`/dashboard/invoices/${inv.id}`}
                className="flex items-center justify-between px-4 py-3 border-b border-hairline last:border-b-0 hover:bg-paperLight"
              >
                <span className="font-mono text-sm">No. {String(inv.number).padStart(4, "0")}</span>
                <span className="text-sm text-inkSoft">{inv.status}</span>
                <span className="font-mono text-sm">${total.toLocaleString()}</span>
              </Link>
            );
          })}
        </div>
      )}
    </div>
  );
}

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <div className="bg-paperLight p-6">
      <div className="text-xs uppercase tracking-widest text-inkSoft mb-2">{label}</div>
      <div className="font-display text-2xl">{value}</div>
    </div>
  );
}
