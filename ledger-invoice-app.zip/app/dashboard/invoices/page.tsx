import { getServerSession } from "next-auth";
import Link from "next/link";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";

export default async function InvoicesPage() {
  const session = await getServerSession(authOptions);
  const invoices = await prisma.invoice.findMany({
    where: { userId: (session!.user as any).id },
    include: { lineItems: true, client: true },
    orderBy: { number: "desc" },
  });

  return (
    <div>
      <div className="flex items-baseline justify-between mb-8">
        <h1 className="font-display text-3xl">Invoices</h1>
        <Link href="/dashboard/invoices/new" className="btn-primary">
          New invoice
        </Link>
      </div>

      {invoices.length === 0 ? (
        <p className="text-inkSoft text-sm">No invoices yet.</p>
      ) : (
        <table className="w-full text-sm border border-hairline">
          <thead>
            <tr className="border-b border-hairline text-left text-xs uppercase tracking-widest text-inkSoft">
              <th className="px-4 py-3 font-normal">No.</th>
              <th className="px-4 py-3 font-normal">Client</th>
              <th className="px-4 py-3 font-normal">Due</th>
              <th className="px-4 py-3 font-normal">Status</th>
              <th className="px-4 py-3 font-normal text-right">Total</th>
            </tr>
          </thead>
          <tbody>
            {invoices.map((inv) => {
              const total = inv.lineItems.reduce((s, li) => s + li.quantity * li.unitPrice, 0);
              return (
                <tr key={inv.id} className="border-b border-hairline last:border-b-0 hover:bg-paperLight">
                  <td className="px-4 py-3">
                    <Link href={`/dashboard/invoices/${inv.id}`} className="font-mono underline underline-offset-4">
                      {String(inv.number).padStart(4, "0")}
                    </Link>
                  </td>
                  <td className="px-4 py-3">{inv.client.name}</td>
                  <td className="px-4 py-3">{new Date(inv.dueDate).toLocaleDateString()}</td>
                  <td className="px-4 py-3">{inv.status}</td>
                  <td className="px-4 py-3 text-right font-mono">${total.toLocaleString()}</td>
                </tr>
              );
            })}
          </tbody>
        </table>
      )}
    </div>
  );
}
