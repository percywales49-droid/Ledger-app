"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";

type LineItem = { description: string; quantity: number; unitPrice: number };

export default function NewInvoicePage() {
  const router = useRouter();
  const [clientName, setClientName] = useState("");
  const [clientEmail, setClientEmail] = useState("");
  const [dueDate, setDueDate] = useState("");
  const [taxRate, setTaxRate] = useState(0);
  const [notes, setNotes] = useState("");
  const [items, setItems] = useState<LineItem[]>([{ description: "", quantity: 1, unitPrice: 0 }]);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const subtotal = items.reduce((s, li) => s + li.quantity * li.unitPrice, 0);
  const tax = subtotal * (taxRate / 100);
  const total = subtotal + tax;

  function updateItem(idx: number, patch: Partial<LineItem>) {
    setItems((prev) => prev.map((it, i) => (i === idx ? { ...it, ...patch } : it)));
  }

  function addItem() {
    setItems((prev) => [...prev, { description: "", quantity: 1, unitPrice: 0 }]);
  }

  function removeItem(idx: number) {
    setItems((prev) => prev.filter((_, i) => i !== idx));
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    setError("");

    const res = await fetch("/api/invoices", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ clientName, clientEmail, dueDate, taxRate, notes, lineItems: items }),
    });

    const body = await res.json();
    setLoading(false);

    if (!res.ok) {
      setError(body.error?.toString?.() || "Something went wrong.");
      return;
    }

    router.push(`/dashboard/invoices/${body.invoice.id}`);
  }

  return (
    <div className="max-w-2xl">
      <h1 className="font-display text-3xl mb-8">New invoice</h1>
      <form onSubmit={handleSubmit} className="space-y-8">
        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="label">Client name</label>
            <input className="field" required value={clientName} onChange={(e) => setClientName(e.target.value)} />
          </div>
          <div>
            <label className="label">Client email (optional)</label>
            <input
              className="field"
              type="email"
              value={clientEmail}
              onChange={(e) => setClientEmail(e.target.value)}
            />
          </div>
          <div>
            <label className="label">Due date</label>
            <input
              className="field"
              type="date"
              required
              value={dueDate}
              onChange={(e) => setDueDate(e.target.value)}
            />
          </div>
          <div>
            <label className="label">Tax rate (%)</label>
            <input
              className="field"
              type="number"
              min={0}
              max={100}
              step={0.1}
              value={taxRate}
              onChange={(e) => setTaxRate(parseFloat(e.target.value) || 0)}
            />
          </div>
        </div>

        <div>
          <label className="label mb-3">Line items</label>
          <div className="border border-hairline">
            <div className="grid grid-cols-[1fr_80px_100px_100px_32px] gap-2 px-3 py-2 text-xs uppercase tracking-widest text-inkSoft border-b border-hairline">
              <span>Description</span>
              <span>Qty</span>
              <span>Unit price</span>
              <span className="text-right">Amount</span>
              <span></span>
            </div>
            {items.map((item, idx) => (
              <div
                key={idx}
                className="grid grid-cols-[1fr_80px_100px_100px_32px] gap-2 px-3 py-2 border-b border-hairline last:border-b-0 items-center"
              >
                <input
                  className="field !py-1.5"
                  required
                  placeholder="Design work"
                  value={item.description}
                  onChange={(e) => updateItem(idx, { description: e.target.value })}
                />
                <input
                  className="field !py-1.5"
                  type="number"
                  min={0}
                  step={0.5}
                  value={item.quantity}
                  onChange={(e) => updateItem(idx, { quantity: parseFloat(e.target.value) || 0 })}
                />
                <input
                  className="field !py-1.5"
                  type="number"
                  min={0}
                  step={0.01}
                  value={item.unitPrice}
                  onChange={(e) => updateItem(idx, { unitPrice: parseFloat(e.target.value) || 0 })}
                />
                <span className="font-mono text-sm text-right">
                  ${(item.quantity * item.unitPrice).toFixed(2)}
                </span>
                <button
                  type="button"
                  onClick={() => removeItem(idx)}
                  disabled={items.length === 1}
                  className="text-inkSoft hover:text-rust disabled:opacity-30"
                  aria-label="Remove line item"
                >
                  ×
                </button>
              </div>
            ))}
          </div>
          <button type="button" onClick={addItem} className="text-sm text-inkSoft hover:text-ink mt-2 underline underline-offset-4">
            + Add line item
          </button>
        </div>

        <div>
          <label className="label">Notes (optional)</label>
          <textarea className="field" rows={3} value={notes} onChange={(e) => setNotes(e.target.value)} />
        </div>

        <div className="border-t border-hairline pt-4 space-y-1 text-sm max-w-xs ml-auto">
          <div className="flex justify-between text-inkSoft">
            <span>Subtotal</span>
            <span className="font-mono">${subtotal.toFixed(2)}</span>
          </div>
          <div className="flex justify-between text-inkSoft">
            <span>Tax ({taxRate}%)</span>
            <span className="font-mono">${tax.toFixed(2)}</span>
          </div>
          <div className="flex justify-between font-display text-lg pt-1">
            <span>Total</span>
            <span className="font-mono">${total.toFixed(2)}</span>
          </div>
        </div>

        {error && <p className="text-rust text-sm">{error}</p>}

        <button type="submit" disabled={loading} className="btn-primary">
          {loading ? "Creating…" : "Create invoice"}
        </button>
      </form>
    </div>
  );
}
