"use client";

import { useRouter } from "next/navigation";
import { useState } from "react";

const STATUSES = ["DRAFT", "SENT", "PAID", "OVERDUE"];

export default function StatusControls({
  invoiceId,
  currentStatus,
}: {
  invoiceId: string;
  currentStatus: string;
}) {
  const router = useRouter();
  const [status, setStatus] = useState(currentStatus);
  const [saving, setSaving] = useState(false);

  async function updateStatus(next: string) {
    setSaving(true);
    setStatus(next);
    await fetch(`/api/invoices/${invoiceId}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ status: next }),
    });
    setSaving(false);
    router.refresh();
  }

  return (
    <div className="flex items-center gap-2">
      {STATUSES.map((s) => (
        <button
          key={s}
          onClick={() => updateStatus(s)}
          disabled={saving}
          className={`text-xs uppercase tracking-widest px-3 py-1.5 border ${
            status === s ? "bg-ink text-paperLight border-ink" : "border-hairline text-inkSoft hover:border-ink"
          }`}
        >
          {s}
        </button>
      ))}
    </div>
  );
}
