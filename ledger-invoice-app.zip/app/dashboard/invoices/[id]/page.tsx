import { getServerSession } from "next-auth";
import { notFound } from "next/navigation";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import StatusControls from "./status-controls";
import PrintButton from "./print-button";

export default async function InvoiceDetail({ params }: { params: { id: string } }) {
  const session = await getServerSession(authOptions);
  const invoice = await prisma.invoice.findFirst({
    where: { id: params.id, userId: (session!.user as any).id },
    include: { lineItems: { orderBy: { sortOrder: "asc" } }, client: true, user: true },
  });

  if (!invoice) notFound();

  const subtotal = invoice.lineItems.reduce((s, li) => s + li.quantity * li.unitPrice, 0);
  const tax = subtotal * (invoice.taxRate / 100);
  const total = subtotal + tax;

  return (
    <div className="max-w-2xl">
      <div className="flex items-center justify-between mb-6 print:hidden">
        <StatusControls invoiceId={invoice.id} currentStatus={invoice.status} />
        <PrintButton />
      </div>

      <div className="border border-ink bg-paperLight p-10">
        <div className="flex justify-between items-start mb-10">
          <div>
            <div className="font-display text-xl">{invoice.user.businessName || invoice.user.name}</div>
            <div className="text-xs text-inkSoft mt-1">{invoice.user.email}</div>
          </div>
          <div className="text-right">
            <div className="font-mono text-xs text-inkSoft">INVOICE</div>
            <div className="font-mono text-xl">No. {String(invoice.number).padStart(4, "0")}</div>
          </div>
        </div>

        <div className="ledger-rule mb-4" />
        <div className="flex justify-between text-sm text-inkSoft mb-8">
          <div>
            <div className="text-xs uppercase tracking-widest mb-1">Bill to</div>
            <div className="text-ink">{invoice.client.name}</div>
            {invoice.client.email && <div>{invoice.client.email}</div>}
          </div>
          <div className="text-right">
            <div className="text-xs uppercase tracking-widest mb-1">Due date</div>
            <div className="text-ink">{new Date(invoice.dueDate).toLocaleDateString()}</div>
          </div>
        </div>

        <table className="w-full text-sm mb-8">
          <thead>
            <tr className="border-b border-hairline text-xs uppercase tracking-widest text-inkSoft">
              <th className="text-left font-normal py-2">Description</th>
              <th className="text-right font-normal py-2">Qty</th>
              <th className="text-right font-normal py-2">Rate</th>
              <th className="text-right font-normal py-2">Amount</th>
            </tr>
          </thead>
          <tbody>
            {invoice.lineItems.map((li) => (
              <tr key={li.id} className="border-b border-hairline">
                <td className="py-2 text-inkSoft">{li.description}</td>
                <td className="py-2 text-right font-mono">{li.quantity}</td>
                <td className="py-2 text-right font-mono">${li.unitPrice.toFixed(2)}</td>
                <td className="py-2 text-right font-mono">${(li.quantity * li.unitPrice).toFixed(2)}</td>
              </tr>
            ))}
          </tbody>
        </table>

        <div className="ml-auto max-w-xs space-y-1 text-sm">
          <div className="flex justify-between text-inkSoft">
            <span>Subtotal</span>
            <span className="font-mono">${subtotal.toFixed(2)}</span>
          </div>
          <div className="flex justify-between text-inkSoft">
            <span>Tax ({invoice.taxRate}%)</span>
            <span className="font-mono">${tax.toFixed(2)}</span>
          </div>
          <div className="flex justify-between font-display text-2xl pt-2 border-t border-hairline">
            <span>Total</span>
            <span className="font-mono">${total.toFixed(2)}</span>
          </div>
        </div>

        {invoice.notes && (
          <div className="mt-8 pt-4 border-t border-hairline text-sm text-inkSoft">{invoice.notes}</div>
        )}
      </div>
    </div>
  );
}
