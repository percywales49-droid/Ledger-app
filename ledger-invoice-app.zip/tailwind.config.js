/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./app/**/*.{js,ts,jsx,tsx}", "./components/**/*.{js,ts,jsx,tsx}"],
  theme: {
    extend: {
      colors: {
        paper: "#EDEFEA",
        paperLight: "#F5F6F2",
        ink: "#1E2A38",
        inkSoft: "#3D4A5C",
        brass: "#B08D57",
        brassLight: "#CBA96D",
        moss: "#3F6B4F",
        rust: "#A34B3D",
        hairline: "#D4D6CE",
      },
      fontFamily: {
        display: ["Fraunces", "serif"],
        body: ["'IBM Plex Sans'", "sans-serif"],
        mono: ["'IBM Plex Mono'", "monospace"],
      },
      borderRadius: {
        none: "0px",
        sm: "2px",
      },
    },
  },
  plugins: [],
};
