import Stripe from "stripe";

export const stripe = new Stripe(process.env.STRIPE_SECRET_KEY as string, {
  apiVersion: "2024-06-20",
});

// The single monthly subscription price. Create this in the Stripe dashboard
// (Product: "Ledger Pro", Price: recurring monthly) and paste the price ID
// into .env as STRIPE_PRICE_ID.
export const MONTHLY_PRICE_ID = process.env.STRIPE_PRICE_ID as string;
