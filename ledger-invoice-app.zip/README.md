# Ledger — Invoicing for independent studios

A complete Next.js 14 app: email/password auth, Postgres via Prisma, Stripe
subscription billing (14-day trial → $12/mo), and a working invoice builder
with sequential numbering and a print-to-PDF view.

## What's real vs. what you need to add

Everything here is fully wired — auth, database writes, Stripe checkout,
webhooks that keep subscription status in sync, and CRUD for invoices. What
you need to supply, because they require your own accounts, are:

1. A Postgres database (free tier works to start)
2. A Stripe account with one recurring monthly Price
3. A place to host it (Vercel is the path of least resistance for Next.js)

## Local setup

```bash
npm install
cp .env.example .env      # fill in the values below
npm run db:push           # creates tables from prisma/schema.prisma
npm run dev
```

## Getting each credential

**DATABASE_URL** — Create a free Postgres database at
[neon.tech](https://neon.tech) or [supabase.com](https://supabase.com),
copy the connection string.

**NEXTAUTH_SECRET** — Run `openssl rand -base64 32` and paste the output.

**STRIPE_SECRET_KEY** — [dashboard.stripe.com/apikeys](https://dashboard.stripe.com/apikeys),
use the test key while developing.

**STRIPE_PRICE_ID** — In Stripe, create a Product called "Ledger Pro" with
one recurring monthly Price (e.g. $12.00/month), then copy that price's ID
(starts with `price_`).

**STRIPE_WEBHOOK_SECRET** — For local testing, install the Stripe CLI and run:
```bash
stripe listen --forward-to localhost:3000/api/stripe/webhook
```
It prints a `whsec_...` value — put that in `.env`. In production, create a
webhook endpoint in the Stripe dashboard pointing at
`https://yourdomain.com/api/stripe/webhook`, subscribed to:
`checkout.session.completed`, `customer.subscription.created`,
`customer.subscription.updated`, `customer.subscription.deleted`.

## Deploying to Vercel

1. Push this folder to a GitHub repo
2. Import it at [vercel.com/new](https://vercel.com/new)
3. Add all the env vars from `.env` in the Vercel project settings
4. Set `NEXTAUTH_URL` to your production URL (e.g. `https://ledger-yourname.vercel.app`)
5. Deploy — Vercel runs `prisma generate` automatically via the `postinstall` script
6. Add the production webhook endpoint in Stripe (see above) and add its
   secret as `STRIPE_WEBHOOK_SECRET` in Vercel

## Project structure

```
app/
  page.tsx                    Landing/marketing page
  login/, register/           Auth pages
  dashboard/                  Protected app (middleware.ts enforces this)
    invoices/new/             Invoice builder
    invoices/[id]/            Invoice view + print + status controls
  api/
    auth/[...nextauth]/       NextAuth handler
    register/                 Account creation
    stripe/checkout/          Starts subscription checkout
    stripe/portal/            Opens Stripe's billing management portal
    stripe/webhook/           Keeps planStatus in sync with Stripe
    invoices/                 Invoice CRUD, enforces active subscription
prisma/schema.prisma          Database schema
lib/                          Prisma, Stripe, and NextAuth config
```

## Extending this

- **Emailing invoices**: wire up [Resend](https://resend.com) or similar in
  a new `app/api/invoices/[id]/send/route.ts`
- **Google sign-in**: add a `GoogleProvider` to `lib/auth.ts` (NextAuth makes
  this a ~10 line addition)
- **PDF export without browser print**: swap the print button for a
  server-rendered PDF using `@react-pdf/renderer`
